public interface ArtTag {
    void generateTag();
}
